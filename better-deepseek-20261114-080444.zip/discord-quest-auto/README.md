# Discord Quest Auto

A Chrome (Manifest V3) extension that automates the Discord quest system: it enrolls you in available quests, accelerates video quests to complete them quickly, and claims completed rewards.

## How it works

Discord's web client completes quests by calling the `/api/v9/quests/*` endpoints with your authenticated session. The extension:

1. **Captures the auth token** by hooking `window.fetch` and `XMLHttpRequest` in the page's MAIN world (content/bridge.js). Every outgoing API request carries the token in the `Authorization` header; the bridge remembers it.
2. **Lists quests** via `GET /quests/@me`, enrolling in each with `POST /quests/{id}/enroll`.
3. **Accelerates video quests** by locating the `<video>` element Discord renders in the quest modal, muting it, and forcing `playbackRate` up to 16x. The client's own heartbeat system reports the (accelerated) progress.
4. **Claims rewards** via `POST /quests/{id}/claim` once `completed_at` is set.
5. **Runs a 30-second alarm loop** in the background service worker so it survives worker sleep, plus reacts live to quest-list responses the client fetches itself.

## Install

1. Open `chrome://extensions`.
2. Enable **Developer mode** (top right).
3. Click **Load unpacked** and select the `discord-quest-auto` folder.
4. Open or refresh a `discord.com/channels/@me` tab (required once so the content scripts can attach).
5. Click the extension icon, flip the power switch to **Running**.

## Usage

- **Refresh** — pull the current quest list.
- **Claim all** — claim every completed-but-unclaimed quest.
- **Boost video** — force the video accelerator on any `<video>` currently on the page. This is what makes `WATCH_VIDEO` quests finish fast: open the quest video in Discord, and the extension drives it at 16x.
- **Settings** — toggle auto-enroll / auto-claim / auto video boost / auto open tab, and set the acceleration rate.

## Quest types

| Type | What the extension does |
|------|-------------------------|
| `WATCH_VIDEO` / `WATCH_VIDEO_ON_MOBILE` | Enrolls, then accelerates the video element to the configured rate until the client reports completion. |
| `PLAY_ACTIVITY` / `ACHIEVEMENT_IN_ACTIVITY` | Enrolls. These run as a Discord embedded activity — join it in the client; the extension keeps the heartbeat loop active. |
| `PLAY_ON_DESKTOP` / `STREAM_ON_DESKTOP` | Enrolls. These require the Discord desktop app and a real game process; the browser cannot fake desktop process detection. |

## Files

```

manifest.json         Manifest V3 config, content-script declarations
background.js         State, alarm loop, tab routing, toolbar icon
content/bridge.js     MAIN-world fetch/XHR hook, quest API driver, video booster
content/content.js    ISOLATED-world relay between bridge and background
popup/popup.html      Dashboard markup
popup/popup.css       Dark UI styling
popup/popup.js        Rendering + action wiring

```

## Notes

- Requires Chrome 111+ for `world: "MAIN"` content scripts.
- The toolbar icon is drawn at runtime via `OffscreenCanvas` in the service worker, so no binary icon files are required.
- If you load the extension while Discord is already open, refresh the Discord tab so the MAIN-world hook installs before Discord's bundle runs.
- The `enroll` and `claim` endpoint shapes are tried across a few known variants. If Discord changes them, the log panel shows the exact HTTP error returned.
- This drives your own authenticated session against Discord's own quest endpoints. Behavior and endpoint shapes are subject to change on Discord's side.
