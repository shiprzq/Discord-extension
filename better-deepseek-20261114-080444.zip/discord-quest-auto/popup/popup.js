// Popup controller. Renders state pushed by the background worker and
// forwards user actions back to it.
const $ = (sel) => document.querySelector(sel);
let state = null;

function send(kind, extra) {
  return chrome.runtime.sendMessage(Object.assign({ kind }, extra || {}));
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function typeLabel(t) {
  return ({
    WATCH_VIDEO: 'Watch video',
    WATCH_VIDEO_ON_MOBILE: 'Watch (mobile)',
    PLAY_ON_DESKTOP: 'Play on PC',
    PLAY_ACTIVITY: 'Activity',
    STREAM_ON_DESKTOP: 'Stream',
    ACHIEVEMENT_IN_ACTIVITY: 'Achievement'
  }[t] || t || 'Quest');
}

function render(s) {
  if (!s) return;
  state = s;

  const power = $('#powerBtn');
  power.classList.toggle('on', !!s.running);
  power.querySelector('.label').textContent = s.running ? 'Running' : 'Off';

  const found = s.quests.length;
  const done = s.quests.filter((q) => q.completedAt).length;
  const claimed = s.quests.filter((q) => q.claimedAt).length;
  const active = s.quests.filter((q) => q.enrolledAt && !q.completedAt).length;

  $('#statFound').textContent = found;
  $('#statDone').textContent = done;
  $('#statClaimed').textContent = claimed;
  $('#statActive').textContent = active;
  $('#questCount').textContent = found;

  $('#setEnroll').checked = !!s.settings.autoEnroll;
  $('#setClaim').checked = !!s.settings.autoClaim;
  $('#setVideo').checked = !!s.settings.autoVideo;
  $('#setOpenTab').checked = !!s.settings.autoOpenTab;
  $('#setRate').value = s.settings.videoRate;
  $('#rateVal').textContent = s.settings.videoRate + 'x';

  renderQuests(s.quests);
  renderLogs(s.logs);
}

function renderQuests(quests) {
  const el = $('#questList');
  if (!quests || !quests.length) {
    el.innerHTML = '<div class="empty">No quests loaded. Open Discord, then hit Refresh.</div>';
    return;
  }
  el.innerHTML = quests.map((q) => {
    const target = q.target || 0;
    const pct = target
      ? Math.min(100, Math.round((q.progress / target) * 100))
      : (q.completedAt ? 100 : 0);

    let status = 'Available', cls = 'avail';
    if (q.claimedAt) { status = 'Claimed'; cls = 'claimed'; }
    else if (q.completedAt) { status = 'Ready to claim'; cls = 'done'; }
    else if (q.enrolledAt) { status = 'In progress'; cls = 'active'; }

    const reward = q.reward
      ? '<div class="q-reward"><span class="q-reward-tag">Reward</span>' + escapeHtml(q.reward) + '</div>'
      : '';

    const meta = target
      ? (q.progress || 0) + ' / ' + target + ' sec'
      : (q.completedAt ? 'Complete' : 'Not started');

    return (
      '<div class="quest ' + cls + '">' +
        '<div class="q-top">' +
          '<span class="q-type">' + escapeHtml(typeLabel(q.type)) + '</span>' +
          '<span class="q-status ' + cls + '">' + status + '</span>' +
        '</div>' +
        '<div class="q-name">' + escapeHtml(q.name) + '</div>' +
        reward +
        '<div class="q-bar"><div class="q-fill" style="width:' + pct + '%"></div></div>' +
        '<div class="q-meta">' + meta + '</div>' +
      '</div>'
    );
  }).join('');
}

function renderLogs(logs) {
  const el = $('#logList');
  if (!logs || !logs.length) {
    el.innerHTML = '<div class="log">No activity yet.</div>';
    return;
  }
  el.innerHTML = logs.slice().reverse().map((l) => {
    const time = new Date(l.t).toLocaleTimeString([], { hour12: false });
    return '<div class="log ' + escapeHtml(l.level) + '"><span class="t">' + time + '</span>' + escapeHtml(l.msg) + '</div>';
  }).join('');
}

async function refreshState() {
  const r = await send('get-state');
  if (r && r.state) render(r.state);
}

function bind() {
  $('#powerBtn').addEventListener('click', async () => {
    await send(state && state.running ? 'stop' : 'start');
    await refreshState();
  });

  $('#refreshBtn').addEventListener('click', async () => {
    await send('refresh');
    await refreshState();
  });

  $('#claimAllBtn').addEventListener('click', async () => {
    await send('claim-all');
    await refreshState();
  });

  $('#boostBtn').addEventListener('click', async () => {
    await send('start-video');
    await refreshState();
  });

  $('#clearLogs').addEventListener('click', async () => {
    await send('clear-logs');
    await refreshState();
  });

  ['setEnroll', 'setClaim', 'setVideo', 'setOpenTab'].forEach((id) => {
    $('#' + id).addEventListener('change', async () => {
      const settings = {
        autoEnroll: $('#setEnroll').checked,
        autoClaim: $('#setClaim').checked,
        autoVideo: $('#setVideo').checked,
        autoOpenTab: $('#setOpenTab').checked
      };
      await send('set-settings', { settings });
    });
  });

  $('#setRate').addEventListener('input', () => {
    $('#rateVal').textContent = $('#setRate').value + 'x';
  });
  $('#setRate').addEventListener('change', async () => {
    await send('set-settings', { settings: { videoRate: Number($('#setRate').value) } });
  });
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.kind === 'state') render(msg.state);
});

(async function init() {
  bind();
  await refreshState();
  setInterval(refreshState, 1500);
})();
