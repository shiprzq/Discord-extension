// MAIN-world bridge. Runs in the Discord page context so it can hook fetch/XHR,
// read the auth token from outgoing requests, and drive the quest API directly.
// Communicates with the isolated-world content script via window.postMessage.
(() => {
  if (window.__DQA_BRIDGE__) return;
  window.__DQA_BRIDGE__ = true;

  const API = 'https://discord.com/api/v9';
  let authToken = null;
  const questCache = new Map();
  const heartbeatKeys = new Map(); // questId -> stream_key captured from real heartbeats

  // ---------------------------------------------------------------- header utils
  function extractHeader(headers, name) {
    if (!headers) return null;
    try {
      if (typeof Headers !== 'undefined' && headers instanceof Headers) return headers.get(name);
      if (Array.isArray(headers)) {
        for (const pair of headers) if (String(pair[0]).toLowerCase() === name) return pair[1];
        return null;
      }
      for (const k in headers) if (k.toLowerCase() === name) return headers[k];
    } catch (e) {}
    return null;
  }

  function rememberToken(raw) {
    if (!raw) return;
    const tok = String(raw).replace(/^(Bot |Bearer )/i, '').trim();
    if (tok.length > 30 && tok !== authToken) authToken = tok;
  }

  // ---------------------------------------------------------------- fetch hook
  const origFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    try {
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      const method = ((init && init.method) || (input && input.method) || 'GET').toUpperCase();

      if (url.includes('/api/')) {
        const auth = extractHeader((init && init.headers) || (input && input.headers), 'authorization');
        if (auth) rememberToken(auth);
      }

      // Capture quest list payloads the client itself fetches.
      if (url.includes('/quests/@me') && method === 'GET') {
        const p = origFetch(input, init).then((res) => {
          try {
            res.clone().json().then((data) => {
              if (data && Array.isArray(data.quests)) {
                data.quests.forEach((q) => questCache.set(q.id, q));
                broadcast('quests-updated', { quests: data.quests });
              }
            }).catch(() => {});
          } catch (e) {}
          return res;
        });
        return p;
      }

      // Learn the stream_key from real heartbeat calls.
      if (/\/quests\/[^/]+\/heartbeat/.test(url) && method === 'POST') {
        try {
          const body = init && init.body;
          if (body) {
            const parsed = typeof body === 'string' ? JSON.parse(body) : body;
            const m = url.match(/\/quests\/([^/]+)\/heartbeat/);
            if (m && parsed && parsed.stream_key) heartbeatKeys.set(m[1], parsed.stream_key);
          }
        } catch (e) {}
      }
    } catch (e) {}
    return origFetch(input, init);
  };

  // ---------------------------------------------------------------- XHR hook
  const origOpen = XMLHttpRequest.prototype.open;
  const origSetHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__dqa_url = url;
    this.__dqa_method = method;
    return origOpen.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    try {
      if (String(name).toLowerCase() === 'authorization' && String(this.__dqa_url || '').includes('/api/')) {
        rememberToken(value);
      }
    } catch (e) {}
    return origSetHeader.call(this, name, value);
  };

  // ---------------------------------------------------------------- api helper
  async function api(method, path, body) {
    if (!authToken) throw new Error('No auth token captured yet. Open Discord and interact once.');
    const res = await fetch(API + path, {
      method,
      headers: {
        'Authorization': authToken,
        'Content-Type': 'application/json',
        'X-Discord-Locale': 'en-US'
      },
      body: body ? JSON.stringify(body) : undefined,
      credentials: 'include'
    });
    const text = await res.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch (e) { data = text; }
    if (!res.ok) {
      const detail = data && typeof data === 'object' ? JSON.stringify(data) : String(data);
      throw new Error('HTTP ' + res.status + ': ' + detail);
    }
    return data;
  }

  async function listQuests() {
    return api('GET', '/quests/@me');
  }

  async function enroll(questId) {
    const variants = [{ location: 11 }, { location: 11, is_targeted: false }, {}];
    let lastErr;
    for (const body of variants) {
      try { return await api('POST', '/quests/' + questId + '/enroll', body); }
      catch (e) { lastErr = e; }
    }
    throw lastErr;
  }

  async function heartbeat(questId, streamKey, terminal) {
    const body = streamKey ? { stream_key: streamKey, terminal: !!terminal } : { terminal: !!terminal };
    return api('POST', '/quests/' + questId + '/heartbeat', body);
  }

  async function claim(questId) {
    try { return await api('POST', '/quests/' + questId + '/claim', {}); }
    catch (e) {
      try { return await api('POST', '/quests/' + questId + '/claim_reward', {}); }
      catch (e2) { throw e; }
    }
  }

  // ---------------------------------------------------------------- video boost
  let boostTimer = null;

  function boostVideos(rate) {
    const vids = Array.from(document.querySelectorAll('video'));
    let touched = 0;
    for (const v of vids) {
      try {
        const target = Math.min(Math.max(rate, 1), 16);
        if (v.playbackRate !== target) v.playbackRate = target;
        v.preservesPitch = false;
        if (!v.muted) v.muted = true;
        if (v.paused) v.play().catch(() => {});
        touched++;
      } catch (e) {}
    }
    return touched;
  }

  function startBoost(rate) {
    stopBoost();
    boostVideos(rate);
    boostTimer = setInterval(() => boostVideos(rate), 400);
  }
  function stopBoost() {
    if (boostTimer) { clearInterval(boostTimer); boostTimer = null; }
  }

  // ---------------------------------------------------------------- messaging
  window.addEventListener('message', async (ev) => {
    const d = ev.data;
    if (!d || d.source !== 'dqa-content') return;
    const { id, type, payload } = d;
    const reply = (ok, data, error) => {
      window.postMessage({ source: 'dqa-bridge', id, ok, data, error }, '*');
    };
    try {
      switch (type) {
        case 'get-token': {
          if (!authToken) {
            try { const t = localStorage.getItem('token'); if (t) rememberToken(JSON.parse(t)); } catch (e) {}
          }
          return reply(true, authToken);
        }
        case 'list-quests':
          return reply(true, await listQuests());
        case 'enroll':
          return reply(true, await enroll(payload.questId));
        case 'heartbeat':
          return reply(true, await heartbeat(payload.questId, payload.streamKey, payload.terminal));
        case 'claim':
          return reply(true, await claim(payload.questId));
        case 'start-boost':
          startBoost(payload && payload.rate ? payload.rate : 16);
          return reply(true, true);
        case 'stop-boost':
          stopBoost();
          return reply(true, true);
        case 'video-count':
          return reply(true, document.querySelectorAll('video').length);
        case 'heartbeat-keys':
          return reply(true, Object.fromEntries(heartbeatKeys));
        default:
          return reply(false, null, 'Unknown bridge type: ' + type);
      }
    } catch (e) {
      reply(false, null, e && e.message ? e.message : String(e));
    }
  });

  function broadcast(event, data) {
    window.postMessage({ source: 'dqa-bridge', event, data }, '*');
  }

  broadcast('bridge-ready', { url: location.href });
})();
