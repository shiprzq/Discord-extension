// Isolated-world relay. Bridges popup/background <-> MAIN-world bridge.js.
(() => {
  if (window.__DQA_CONTENT__) return;
  window.__DQA_CONTENT__ = true;

  const pending = new Map();
  let seq = 0;

  function callBridge(type, payload, timeoutMs = 10000) {
    return new Promise((resolve, reject) => {
      const id = 'c' + (++seq);
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new Error('Bridge timeout (' + type + ')'));
      }, timeoutMs);
      pending.set(id, { resolve, reject, timer });
      window.postMessage({ source: 'dqa-content', id, type, payload }, '*');
    });
  }

  window.addEventListener('message', (ev) => {
    const d = ev.data;
    if (!d || d.source !== 'dqa-bridge') return;

    if (d.event) {
      chrome.runtime.sendMessage({ kind: 'bridge-event', event: d.event, data: d.data }).catch(() => {});
      return;
    }
    if (d.id && pending.has(d.id)) {
      const entry = pending.get(d.id);
      clearTimeout(entry.timer);
      pending.delete(d.id);
      if (d.ok) entry.resolve(d.data);
      else entry.reject(new Error(d.error || 'Bridge error'));
    }
  });

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.kind !== 'bridge-call') return;
    callBridge(msg.type, msg.payload).then(
      (data) => sendResponse({ ok: true, data }),
      (err) => sendResponse({ ok: false, error: err && err.message ? err.message : String(err) })
    );
    return true; // keep channel open for async response
  });

  chrome.runtime.sendMessage({ kind: 'content-ready', url: location.href }).catch(() => {});
})();
