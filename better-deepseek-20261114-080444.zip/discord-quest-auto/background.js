// Service worker. Owns state, runs the completion loop on a 30s alarm,
// routes bridge calls to the Discord tab, and draws the toolbar icon.

const STORAGE_KEY = 'dqa_state_v1';
const CYCLE_ALARM = 'dqa-cycle';

const state = {
  running: false,
  settings: {
    autoEnroll: true,
    autoClaim: true,
    autoVideo: true,
    autoOpenTab: true,
    videoRate: 16
  },
  quests: [],
  logs: [],
  tabId: null
};

let cycling = false;

// ---------------------------------------------------------------- persistence
chrome.storage.local.get(STORAGE_KEY).then((obj) => {
  const saved = obj && obj[STORAGE_KEY];
  if (saved) {
    state.running = !!saved.running;
    if (saved.settings) Object.assign(state.settings, saved.settings);
    state.quests = Array.isArray(saved.quests) ? saved.quests : [];
    state.logs = Array.isArray(saved.logs) ? saved.logs : [];
  }
  if (state.running) startLoop();
});

function persist() {
  chrome.storage.local.set({
    [STORAGE_KEY]: {
      running: state.running,
      settings: state.settings,
      quests: state.quests,
      logs: state.logs.slice(-400)
    }
  });
}

function publicState() {
  return {
    running: state.running,
    settings: state.settings,
    quests: state.quests,
    logs: state.logs.slice(-250),
    hasTab: !!state.tabId
  };
}

function pushState() {
  chrome.runtime.sendMessage({ kind: 'state', state: publicState() }).catch(() => {});
}

function log(level, msg) {
  state.logs.push({ t: Date.now(), level, msg });
  if (state.logs.length > 600) state.logs = state.logs.slice(-600);
  persist();
  pushState();
}

// ---------------------------------------------------------------- tabs
async function findDiscordTab() {
  const tabs = await chrome.tabs.query({ url: ['https://discord.com/*', 'https://*.discord.com/*'] });
  const preferred = tabs.find((t) => t.url && t.url.includes('discord.com/channels')) || tabs[0];
  if (preferred) {
    state.tabId = preferred.id;
    return preferred;
  }
  return null;
}

async function ensureTab() {
  if (state.tabId) {
    try {
      const t = await chrome.tabs.get(state.tabId);
      if (t && t.url && t.url.includes('discord.com')) return t;
    } catch (e) { state.tabId = null; }
  }
  const existing = await findDiscordTab();
  if (existing) return existing;
  if (state.settings.autoOpenTab) {
    log('info', 'Opening Discord tab...');
    const tab = await chrome.tabs.create({ url: 'https://discord.com/channels/@me', active: false });
    state.tabId = tab.id;
    await new Promise((r) => setTimeout(r, 7000));
    return tab;
  }
  throw new Error('No Discord tab open');
}

async function callTab(type, payload) {
  if (!state.tabId) await findDiscordTab();
  if (!state.tabId) throw new Error('No Discord tab');
  let resp;
  try {
    resp = await chrome.tabs.sendMessage(state.tabId, { kind: 'bridge-call', type, payload });
  } catch (e) {
    const m = String((e && e.message) || e);
    if (m.includes('Receiving end') || m.includes('Could not establish')) {
      throw new Error('Content script missing — refresh the Discord tab');
    }
    throw e;
  }
  if (!resp) throw new Error('No response from tab');
  if (!resp.ok) throw new Error(resp.error);
  return resp.data;
}

// ---------------------------------------------------------------- quest model
function summarize(q) {
  const cfg = (q && q.config) || {};
  const tc = cfg.task_config || cfg.taskConfig || {};
  const us = (q && q.user_status) || {};
  const prog = us.progress || {};
  const rewardCfg = Array.isArray(cfg.rewards_config) ? cfg.rewards_config[0] : null;

  return {
    id: q.id,
    name:
      cfg.quest_name ||
      (cfg.messages && cfg.messages.quest_name) ||
      (cfg.application && cfg.application.name) ||
      ('Quest ' + String(q.id).slice(0, 6)),
    type: tc.type || cfg.type || 'UNKNOWN',
    target: Number(tc.target || tc.target_time || cfg.target || 0),
    progress: Number(prog.value || prog.progress || 0),
    enrolledAt: us.enrolled_at || null,
    completedAt: us.completed_at || null,
    claimedAt: us.claimed_at || null,
    reward:
      (rewardCfg && rewardCfg.messages && rewardCfg.messages.name) ||
      cfg.reward_name ||
      ''
  };
}

function updateBadge() {
  const claimable = state.quests.filter((q) => q.completedAt && !q.claimedAt).length;
  chrome.action.setBadgeText({ text: claimable ? String(claimable) : '' }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ color: '#3ba55c' }).catch(() => {});
}

async function refreshQuests() {
  const data = await callTab('list-quests', null);
  const list = (data && data.quests) || [];
  state.quests = list.map(summarize);
  persist();
  updateBadge();
  pushState();
  return state.quests;
}

// ---------------------------------------------------------------- cycle
async function runCycle() {
  if (!state.running || cycling) return;
  cycling = true;
  try {
    await ensureTab();
    await refreshQuests();

    for (const q of state.quests) {
      if (q.claimedAt) continue;

      if (q.completedAt) {
        if (state.settings.autoClaim) {
          try {
            await callTab('claim', { questId: q.id });
            log('success', 'Claimed: ' + q.name);
          } catch (e) {
            log('warn', 'Claim failed "' + q.name + '": ' + e.message);
          }
        }
        continue;
      }

      if (!q.enrolledAt && state.settings.autoEnroll) {
        try {
          await callTab('enroll', { questId: q.id });
          log('info', 'Enrolled: ' + q.name);
        } catch (e) {
          log('warn', 'Enroll failed "' + q.name + '": ' + e.message);
        }
      }

      if ((q.type === 'WATCH_VIDEO' || q.type === 'WATCH_VIDEO_ON_MOBILE') && state.settings.autoVideo) {
        try { await callTab('start-boost', { rate: state.settings.videoRate }); }
        catch (e) { /* tab may not have a video yet; harmless */ }
      }
    }

    // Re-pull to catch anything the client changed during the pass.
    await refreshQuests();
  } catch (e) {
    log('error', 'Cycle: ' + e.message);
  } finally {
    cycling = false;
    updateBadge();
  }
}

function startLoop() {
  chrome.alarms.create(CYCLE_ALARM, { periodInMinutes: 0.5 });
  runCycle();
}
function stopLoop() {
  chrome.alarms.clear(CYCLE_ALARM);
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === CYCLE_ALARM && state.running) runCycle();
});

// ---------------------------------------------------------------- icon
function drawIcon(size) {
  const canvas = new OffscreenCanvas(size, size);
  const ctx = canvas.getContext('2d');
  const s = size;
  const r = s * 0.22;

  ctx.fillStyle = '#5865F2';
  ctx.beginPath();
  ctx.moveTo(r, 0);
  ctx.arcTo(s, 0, s, r, r);
  ctx.arcTo(s, s, s - r, s, r);
  ctx.arcTo(0, s, 0, s - r, r);
  ctx.arcTo(0, 0, r, 0, r);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = s * 0.12;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.moveTo(s * 0.27, s * 0.52);
  ctx.lineTo(s * 0.44, s * 0.68);
  ctx.lineTo(s * 0.74, s * 0.35);
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(s * 0.79, s * 0.23, s * 0.055, 0, Math.PI * 2);
  ctx.fill();

  return ctx.getImageData(0, 0, s, s);
}

async function applyIcon() {
  try {
    const imageData = {
      16: drawIcon(16),
      32: drawIcon(32),
      48: drawIcon(48),
      128: drawIcon(128)
    };
    await chrome.action.setIcon({ imageData });
  } catch (e) { /* OffscreenCanvas unsupported — silently skip */ }
}

chrome.runtime.onInstalled.addListener(() => {
  applyIcon();
  chrome.action.setBadgeBackgroundColor({ color: '#3ba55c' });
});
chrome.runtime.onStartup.addListener(async () => {
  applyIcon();
  const obj = await chrome.storage.local.get(STORAGE_KEY);
  if (obj && obj[STORAGE_KEY] && obj[STORAGE_KEY].running) {
    state.running = true;
    startLoop();
  }
});

// ---------------------------------------------------------------- messaging
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.kind) {
        case 'content-ready':
          if (sender && sender.tab) state.tabId = sender.tab.id;
          sendResponse({ ok: true, state: publicState() });
          break;

        case 'get-state':
          sendResponse({ ok: true, state: publicState() });
          break;

        case 'set-settings':
          Object.assign(state.settings, msg.settings || {});
          persist();
          pushState();
          sendResponse({ ok: true });
          break;

        case 'start':
          state.running = true;
          persist();
          startLoop();
          log('info', 'Auto-run started');
          sendResponse({ ok: true });
          break;

        case 'stop':
          state.running = false;
          stopLoop();
          persist();
          log('info', 'Auto-run stopped');
          sendResponse({ ok: true });
          break;

        case 'refresh':
          await ensureTab();
          await refreshQuests();
          log('info', 'Refreshed ' + state.quests.length + ' quests');
          sendResponse({ ok: true, state: publicState() });
          break;

        case 'claim-all': {
          let claimed = 0;
          for (const q of state.quests) {
            if (!q.claimedAt && q.completedAt) {
              try {
                await callTab('claim', { questId: q.id });
                claimed++;
                log('success', 'Claimed: ' + q.name);
              } catch (e) {
                log('warn', 'Claim failed "' + q.name + '": ' + e.message);
              }
            }
          }
          await refreshQuests();
          sendResponse({ ok: true, claimed, state: publicState() });
          break;
        }

        case 'start-video':
          await ensureTab();
          await callTab('start-boost', { rate: state.settings.videoRate });
          log('info', 'Video boost engaged at ' + state.settings.videoRate + 'x');
          sendResponse({ ok: true });
          break;

        case 'stop-video':
          await callTab('stop-boost', null).catch(() => {});
          sendResponse({ ok: true });
          break;

        case 'clear-logs':
          state.logs = [];
          persist();
          pushState();
          sendResponse({ ok: true });
          break;

        case 'bridge-event':
          if (msg.event === 'quests-updated' && msg.data && Array.isArray(msg.data.quests)) {
            state.quests = msg.data.quests.map(summarize);
            persist();
            updateBadge();
            pushState();
          }
          sendResponse({ ok: true });
          break;

        default:
          sendResponse({ ok: false, error: 'Unknown message kind: ' + msg.kind });
      }
    } catch (e) {
      sendResponse({ ok: false, error: (e && e.message) || String(e) });
    }
  })();
  return true;
});

// ---------------------------------------------------------------- tab lifecycle
chrome.tabs.onRemoved.addListener((tabId) => {
  if (state.tabId === tabId) state.tabId = null;
});
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === 'complete' && tab.url && tab.url.includes('discord.com')) {
    state.tabId = tabId;
  }
});
